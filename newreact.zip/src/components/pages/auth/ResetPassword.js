import React from 'react';

const ResetPassword = () => {
    return(
        <>
            
        </>
    )
}
export default ResetPassword;